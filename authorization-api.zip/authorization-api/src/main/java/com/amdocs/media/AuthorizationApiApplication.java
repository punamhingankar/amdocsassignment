package com.amdocs.media;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizationApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorizationApiApplication.class, args);
	}

}
