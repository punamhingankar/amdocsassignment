package com.amdocs.media;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
