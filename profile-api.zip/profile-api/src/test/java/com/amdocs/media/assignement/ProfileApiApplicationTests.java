package com.amdocs.media.assignement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
